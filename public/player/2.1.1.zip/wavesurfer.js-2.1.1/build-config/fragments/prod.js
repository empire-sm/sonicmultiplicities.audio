/* eslint-env node */

module.exports = {
    devtool: 'source-map'
};
